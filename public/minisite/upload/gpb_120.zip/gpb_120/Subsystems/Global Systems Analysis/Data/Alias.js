var xmlAliasData = "";
xmlAliasData += '<?xml version=\"1.0\" encoding=\"utf-8\"?>';
xmlAliasData += '<CatapultAliasFile>';
xmlAliasData += '    <!-- saved from url=(0016)http://localhost -->';
xmlAliasData += '    <Map Name=\"GSA_GUIDE\" Link=\"Global Systems Analysis/Global Systems Analysis.htm\" ResolvedId=\"9000\" />';
xmlAliasData += '</CatapultAliasFile>';
MadCap.Utilities.Xhr._FilePathToXmlStringMap.Add('Alias', xmlAliasData);
