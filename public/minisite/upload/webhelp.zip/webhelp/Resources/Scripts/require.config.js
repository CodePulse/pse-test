require.config({
    urlArgs: 't=635926213751017978'
});