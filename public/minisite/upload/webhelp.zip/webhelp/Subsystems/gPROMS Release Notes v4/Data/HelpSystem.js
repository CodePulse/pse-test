var xmlHelpSystemData = "";
xmlHelpSystemData += '<?xml version=\"1.0\" encoding=\"utf-8\"?>';
xmlHelpSystemData += '<WebHelpSystem DefaultUrl=\"Content/Topics/Overview of the new version.htm\" Toc=\"Data/Toc.js\" Index=\"Data/Index.js\" Concepts=\"Data/Concepts.js\" BrowseSequence=\"Data/BrowseSequence.js\" Glossary=\"Data/Glossary.js\" SearchDatabase=\"Data/Search.js\" Alias=\"Data/Alias.xml\" Synonyms=\"Data/Synonyms.xml\" SearchFilterSet=\"Data/Filters.js\" SkinName=\"HTML5\" Skins=\"HTML5\" BuildTime=\"03/03/2016 16:46:53\" BuildVersion=\"11.1.2.31113\" TargetType=\"WebHelp2\" SkinTemplateFolder=\"Skin/\" InPreviewMode=\"false\" MoveOutputContentToRoot=\"false\" MakeFileLowerCase=\"false\" UseCustomTopicFileExtension=\"false\" PreventExternalUrls=\"false\" EnableResponsiveOutput=\"false\" IncludeGlossarySearchResults=\"true\" ResultsPerPage=\"20\">';
xmlHelpSystemData += '    <!-- saved from url=(0016)http://localhost -->';
xmlHelpSystemData += '    <CatapultSkin Version=\"2\" SkinType=\"WebHelp2\" Comment=\"HTML5 skin\" Anchors=\"Width,Height\" Width=\"800\" Height=\"600\" Top=\"0\" Left=\"0\" Bottom=\"0\" Right=\"0\" Tabs=\"TOC\" DefaultTab=\"TOC\" UseBrowserDefaultSize=\"true\" UseDefaultBrowserSetup=\"True\" AutoSyncTOC=\"true\" NavigationLinkTop=\"true\" EnableResponsiveOutput=\"false\" Name=\"HTML5\">';
xmlHelpSystemData += '        <Toolbar EnableCustomLayout=\"true\" Buttons=\"ExpandAll|Print|RemoveHighlight|Separator|Filler|PreviousTopic|CurrentTopicIndex|NextTopic\" />';
xmlHelpSystemData += '    </CatapultSkin>';
xmlHelpSystemData += '</WebHelpSystem>';
MadCap.Utilities.Xhr._FilePathToXmlStringMap.Add('HelpSystem', xmlHelpSystemData);
