var xmlAliasData = "";
xmlAliasData += '<?xml version=\"1.0\" encoding=\"utf-8\"?>';
xmlAliasData += '<CatapultAliasFile>';
xmlAliasData += '    <!-- saved from url=(0016)http://localhost -->';
xmlAliasData += '    <Map Name=\"ReleaseNotes\" Link=\"Topics/Overview of the new version.htm\" ResolvedId=\"10\" />';
xmlAliasData += '</CatapultAliasFile>';
MadCap.Utilities.Xhr._FilePathToXmlStringMap.Add('Alias', xmlAliasData);
