var xmlAliasData = "";
xmlAliasData += '<?xml version=\"1.0\" encoding=\"utf-8\"?>';
xmlAliasData += '<CatapultAliasFile>';
xmlAliasData += '    <!-- saved from url=(0016)http://localhost -->';
xmlAliasData += '    <Map Name=\"FPI_USING_IT\" Link=\"Topics/x593.html\" ResolvedId=\"1000\" />';
xmlAliasData += '    <Map Name=\"GOPCFPI\" Link=\"Topics/gOPCFPI.html\" ResolvedId=\"1001\" />';
xmlAliasData += '</CatapultAliasFile>';
MadCap.Utilities.Xhr._FilePathToXmlStringMap.Add('Alias', xmlAliasData);
