var xmlAliasData = "";
xmlAliasData += '<?xml version=\"1.0\" encoding=\"utf-8\"?>';
xmlAliasData += '<CatapultAliasFile>';
xmlAliasData += '    <!-- saved from url=(0016)http://localhost -->';
xmlAliasData += '    <Map Name=\"LandingPage\" Link=\"Topics/Getting started.htm\" ResolvedId=\"1\" />';
xmlAliasData += '</CatapultAliasFile>';
MadCap.Utilities.Xhr._FilePathToXmlStringMap.Add('Alias', xmlAliasData);
